<?php
require_once("header.php");
?>



<!DOCTYPE html>
<html>
<head>
<title>Font Awesome Icons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<h1>Payment methods</h1>


<i class="fa fa-cc-visa" style="font-size:48px;color:red"></i><i class="fa fa-cc-paypal" style="font-size:48px;color:red"></i>  <i class="fa-brands fa-google-pay" style="font-size:48px;color:red"></i>

</body>
</html> 




<?php
include("database.php");
//print_r($_SESSION);
$uname=""; if(isset($_SESSION["uname"]) && $_SESSION["uname"]) $uname=$_SESSION["uname"]; 
$cart=[]; if(isset($_SESSION["cart"]) && $_SESSION["cart"]) $cart=$_SESSION["cart"]; 
$total = 0;
foreach ($cart as $value) {
  //print_r($value);
  $total = $total+intval($value["price"]);
}
//echo "$total";
if(isset($_REQUEST["action1"]))
{

	
	$sql = "select * from userinfo where username='$uname'";
	$result = $con->query($sql);
    if($result->num_rows>0)
    {
        echo("<table class='table'>");
        echo("<tr><th>fname</th><th>lName</th><th>address</th>"."<th>mobile number</th><th>Grand Total</tr>");
        while($row = $result->fetch_assoc())
        {
            echo("<tr>");
            echo("<td>".$row["firstname"]."</td><td>".$row["lastname"]."</td><td>".$row["address"]."</td><td>".$row["mobile"]."</td><td>$total</td>");
            
            echo("</tr>");
        }
        echo("</table>");
    }
    else
    {
    	"Error in ".$sql."".$con->error; 
    }
    
}

?>
</body>
</html>