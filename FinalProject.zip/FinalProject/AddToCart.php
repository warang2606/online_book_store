<?php
require_once("header.php");

if(!isset($_SESSION["uname"]))
 {
    header("location:login.php");
 }   
 else
 {
    $bid=$_REQUEST["bid"];
    $bname=$_REQUEST["bname"];
    $price=$_REQUEST["price"];
    $qty=$_REQUEST["qty"];
    $data=array($bname,$price,$qty);

    if(!isset($_SESSION["cart"]))
    {
        $cart=array();
        $_SESSION["cart"]=$cart;
    }
    else
    {
        $cart=$_SESSION["cart"];
    }

    if(array_key_exists($bid, $cart))  //to avoid adding duplicate item
    {
        echo("item already in cart");
    }
    else
    {
        $cart["$bid"]=$data;  //key and value pair
        //print_r($cart);

    }
    $_SESSION["cart"]=$cart;    //update cart with new item
 }
 ?>
  <!-- <?php
//require_once("header.php");
?> -->






<script>
function displayConfirm()
{
    ans = confirm("Are you sure you want to delete?");
    if(ans)
    {
        myform.submit();
    }
    
}
</script>


<div class="container">
    <?php
    if(!isset($_SESSION["cart"]))
    {
        echo("<h1>NO items in cart</h1>");
    }
    else
    {
        $total=0;
        echo("<table class='table'>");
        echo("<tr><th>Bid</th><th>Bname</th><th>Price</th><th>Quantity</th></tr>");
        $cart=$_SESSION["cart"];
        foreach ($cart as $k => $value) 
        {
            echo ("<form method='post' name='myform' action='removeFromCart.php'>");
            echo("<tr>");
            echo("<td>".$k."<input type='hidden' name='bid' value='".$k."'/></td>
            <td>".$value[0]."</td><td>".$value[1]."</td><td>".$value[2]."</td>
            <td><input type='button' value='Remove From Cart' onclick='displayConfirm()'/></td>");
            echo("</tr>");
            echo ("</form>");
            $total = $total+ $value[1]*$value[2];
        }
            echo("</table>");
            echo("<form action='MakePayment.php' method='post'>");
            //echo ("<p>Total = ".$total."</p>");
            echo"<span>Total =</span><input type='text' name='amt' value='".$total."' readonly/>";
            echo "<br><br>";
            echo "<input type='submit' name='amt_submit' value='proceed to payment'/>";
            echo("</form>");

        }
    ?>

<!--<a href="MakePayment.php">Procced to Make Payment</a> -->
</div>
<?php
require_once("footer.html");
?>


