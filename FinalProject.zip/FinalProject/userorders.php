<?php
require_once("header.php")
?>
<html>
<head>
    <style type="text/css">
        .button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button4 {border-radius: 12px; float: right;}
    </style>
<a href="adminmodules.php">
	<button  class="button button4">Back to admin panel</button>

</a>

<h3>User Orders Details</h3>

<?php
include("database.php");

$sql="select * from users_orders";
$result=$con->query($sql);
if($result->num_rows>0)
{
	echo("<table class='table text-center'>");
	echo("<tr><th class='text-center'>Order ID</th><th class='text-center'>Book Name</th><th class='text-center'>Price</th><th class='text-center'>Quantity</th>");
	while($row = $result->fetch_assoc())
	{
		echo("<tr>");
		echo("<td>".$row["order_id"]."</td><td>".$row["bname"]."</td><td>".$row["price"]."</td><td>".$row["Quantity"]."</td>");
      }
	echo("</table>");
}
else
    {
      echo "Error in ".$sql."
".$db->error; }

require_once("footer.html");

?>