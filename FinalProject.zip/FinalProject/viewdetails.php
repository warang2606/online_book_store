<?php
require_once("header.php");
?>

<div class="container">
    <h1>Book Details</h1>
    <form method="post" action="manage_cart.php">
<?php
include("database.php");
//Get bid from querystring
    $bid = $_REQUEST["bid"];
    $sql = "select b.bid,b.bname,b.price,b.imageurl,"."c.cname ,b.author,b.description from book b inner join category c on "."b.cid = c.cid where b.bid = ".$bid;
    $result = $con->query($sql);

    if($result->num_rows>0)
    {
        echo("<table class='table'>");
        if($row = $result->fetch_assoc())
        {
            echo("<tr><td>Bid</td><td>".$row["bid"]."<input type='hidden' name='bid' value=".$row["bid"]."></td></tr>");
            echo("<tr><td>BName</td><td>".$row["bname"]."<input type='hidden' name='bname' value=".$row["bname"]."></td></tr>");
            echo("<tr><td>Price</td><td>".$row["price"]."<input type='hidden' name='price' value=".$row["price"]."></td></tr>");
            echo("<tr><td>Category</td><td>".$row["cname"]."</td></tr>");
            echo("<tr><td>Author</td><td>".$row["author"]."</td></tr>");
            echo("<tr><td>Description</td><td>".$row["description"]."</td></tr>");
            echo("<tr><td>Image</td><td><img src='Images".$row["imageurl"]."' height='50' width='60'/></td></tr>");
            
            
        }
        
    }

?>
<tr><td>
<button type="submit" name="Add_To_Cart"class="btn-success">
    Add To Cart</button></td><td></td></tr>
</table>
</div>
<?php
require_once("footer.html");

?>