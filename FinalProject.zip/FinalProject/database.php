<?php
$servername="localhost:3307";
$username="root";
$password="";
$database="bookstore";
$con= new mysqli($servername,$username,$password,$database);
if($con->connect_error)
{
    echo("some problem occured");
}
else
{
    echo("");
}
?>
