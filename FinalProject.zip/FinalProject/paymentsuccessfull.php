<?php
  require_once("header.php");
?> 


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>payment successfull</h1>


<?php
require_once("footer.html");
?>
</body>
</html>