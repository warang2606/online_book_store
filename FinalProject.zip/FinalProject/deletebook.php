<?php
require_once("header.php");
?>

<?php
if(isset($_REQUEST["ans"]))
{
    if($_REQUEST["ans"]=="yes")
    {
        require_once("database.php");
        $bid=$_REQUEST["bid"];
        $sql="delete from book where bid=$bid" AND ("set @autobid :=0;
        update book set bid =@autobid := (@autobid+1);
        alter table book Auto_increment =1;");		
        $con->query($sql);
       
        $con->close();
    }
    

    header("location:book.php");

    
}
?>
<form method="post">
<table border='1'>
<tr><td>Are you sure you want to delete?</td><tr>
<tr><td><input type="submit" value="yes" name="ans"></td><td><input type="submit" value="no" name="ans"></td></tr>
</table>
</form>

