<?php
require_once("header.php");
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
?>
<html>
<head>
    <style type="text/css">
        .button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button4 {border-radius: 12px;}
.button5 {border-radius: 12px; float: right;}
    </style>
<body>
<h3>User Orders</h3>


<a href="adminmodules.php">
    <button  class="button button5">Back To Admin Panel</button>
</a>
</body>
</head>
</html>

<?php

include("database.php");
    $sql = "select order_manager.order_id,order_manager.full_name,order_manager.phone_no,order_manager.address,order_manager.pay_mode,users_orders.bname,users_orders.price,users_orders.Quantity From order_manager INNER JOIN users_orders ON order_manager.order_id = users_orders.order_id order by order_manager.order_id";
    $result = $con->query($sql);
    if($result->num_rows>0)
    {
        echo("<table class='table'>");
        echo("<tr><th>Order ID</th><th>Full Name</th><th>Phone Number</th>"."<th>Address</th><th>Pay Mode</th><th>Book Name</th><th>Price</th><th>Quantity</th></tr>");
        while($row = $result->fetch_assoc())
        {
            echo("<tr>");
            echo("<td>".$row["order_id"]."</td><td>".$row["full_name"]."</td><td>".$row["phone_no"]."</td><td>".$row["address"]."</td><td>".$row["pay_mode"]."</td><td>".$row["bname"]."</td><td>".$row["price"]."</td><td>".$row["Quantity"]."</td>");
           
            echo("</tr>");
        }
        echo("</table>");
    }
    else
    {
      echo "Error in ".$sql."
".$db->error; }


require_once("footer.html");
?>



