<?php
session_start();
require_once("database.php");
if(isset($_REQUEST["login"]))
{
$uname=$_REQUEST["uname"];
$pwd=$_REQUEST["pwd"];
$sql="select count(*) as 'count' from userinfo where username='$uname' and password='$pwd'";
$result=$con->query($sql);
if($result->num_rows>0)
{
    $row=$result->fetch_assoc();
    if($row["count"]==1)
    {
        $_SESSION["uname"]=$uname;
        header("location:home.php");
    }
    else
    {
        header("location:login.php");
    }
}
}

?>