<?php
require_once("header.php");
?>

<html>
<body>
<?php
include("database.php");
if(isset($_REQUEST["register"]))
{
	
	$fname=$_REQUEST["fname"];
	$lname=$_REQUEST["lname"];
	$address=$_REQUEST["address"];
	$mobile = $_REQUEST["mobile"];
	$email=$_REQUEST["email"];
	$uname=$_REQUEST["uname"];
	$password=$_REQUEST["pwd"];
	$sql="INSERT INTO userinfo(firstname,lastname,address,mobile,email,username,password)VALUES('$fname','$lname','$address',$mobile,'$email','$uname','$password')";
	$con->query($sql);
	//echo ($sql);
	$con->close();
	header("location:login.php");
    
    

}

?>
<div class="container">
<form method="post">
<table class='table'>
<tr><td>First Name</td><td><input type="text" name="fname" required></td></tr>
<tr><td>Last Name</td><td><input type="text" name="lname" required></td></tr>
<tr><td>Your Address</td><td><input type="text" name="address" required></td></tr>
<tr><td>Mobile Number</td><td><input type="number" name="mobile" required></td></tr>
<tr><td>Email</td><td><input type="email" name="email" required></td></tr>
<tr><td>Username</td><td><input type="text" name="uname" required></td></tr>
<tr><td>Password</td><td><input type="password" name="pwd" required></td></tr>
</table>
<tr><td><button type="submit" class="btn-warning"  name="register">Register Me</td></tr>
<tr><td><button type="button" formaction="userdetails.php" style="display: none;">submit2</button></td></tr>
</form>
</div>
</body>
</html>

<?php
require_once("footer.html");
?>





