<?php
require_once("header.php");
?>


<?php
if(isset($_REQUEST["ans"]))
{
    if($_REQUEST["ans"]=="yes")
    {
        require_once("database.php");
        $cid=$_REQUEST["cid"];
        $sql="delete from category where cid=$cid";
        $con->query($sql);
        $con->close();
    }
    header("location:category.php");
    
}
?>
<form method="post">
<table border='1'>
<tr><td>Are you sure you want to delete?</td><tr>
<tr><td><input type="submit" value="yes" name="ans"></td><td><input type="submit" value="no" name="ans"></td></tr>
</table>
</from>



