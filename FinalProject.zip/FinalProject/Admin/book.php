<?php
require_once("../header.php");
?>
<h3>Books</h3>
<a href="addbook.php">Add Book</a>
<?php
/*
include("../database.php");
    $sql = "select b.bid,b.bname,b.price,b.description,b.author,b.imageurl, "." c.cname from book b inner join category c on b.cid = c.cid order by bid asc";
    $result = $con->query($sql);
    if($result->num_rows>0)
    {
        echo("<table class='table'>");
        echo("<tr><th>Bid</th><th>BName</th><th>Price</th>"."<th>Description</th><th>Author</th><th>Category Name</th><th>Image</th><th>Edit</th><th>Delete</th></tr>");
        while($row = $result->fetch_assoc())
        {
            echo("<tr>");
            echo("<td>".$row["bid"]."</td><td>".$row["bname"]."</td><td>".$row["price"]."</td><td>".$row["description"]."</td><td>".$row["author"]."</td><td>".$row["cname"]."</td><td><img src='../Images/". $row["imageurl"]."' height='80' width='60'/></td>");
            echo("<td><a href=editbook.php?bid=".$row["bid"].">Edit</a></td>");
            echo("<td><a href=deletebook.php?bid=".$row["bid"].">Delete</a></td>");
            echo("</tr>");
        }
        echo("</table>");
    }

require_once("../footer.html");
*/
?>