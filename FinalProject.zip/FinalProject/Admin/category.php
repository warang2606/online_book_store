<?php
require_once("../header.php");
?>
<h3>Categories</h3>
<a href="addCategory.php">Add Category</a>
<?php
/*
include("../database.php");


    $sql = "select * from category";
    $result = $con->query($sql);
  if($result->num_rows>0)
    {
        echo("<table class='table'>");
        echo("<tr><th>Cid</th><th>CName</th>"."<th>Edit</th><th>Delete</th></tr>");
        while($row = $result->fetch_assoc())
        {
            echo("<tr>");
            echo("<td>".$row["cid"]."</td><td>".$row["cname"]."</td>");
            echo("<td><a href=editCategory.php?cid=".$row["cid"].">Edit</a></td>");
            echo("<td><a href=deleteCategory.php?cid=".$row["cid"].">Delete</a></td>");
            echo("</tr>");

        }
        echo("</table>");
    }
require_once("../footer.html");
*/
?>