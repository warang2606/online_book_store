

<?php

require_once("../header.php");
?>

<?php
if(isset($_REQUEST["action"]))
{

    include("../database.php");

    $sql = "insert into Category (cname) values ('".$_REQUEST["cname"]."')";
        
        $con->query($sql);
        header("Location:category.php");
}
    

?>
<form method="post">
    <table class="table">
       <tr><td>Category Name</td>
        <td><input type="text" name="cname"/></td></tr>
    <tr><td><button class="btn-success" name="action" type="submit">Add Category</button></td><td></td></tr>
    </table>
</form>

<?php
require_once("../footer.html");
?>