<?php
if(isset($_REQUEST["update"]))
{
    require_once("../database.php");
    $cid=$_REQUEST["cid"];
    $cname=$_REQUEST["cname"];
    $sql="update category set cname='$cname' where cid=$cid";
    $con->query($sql);
    $con->close();
    header("location:category.php");
}
?>
<?php
require_once("../database.php");
$cid=$_REQUEST["cid"];
$sql="select * from category where cid=$cid";
$result=$con->query($sql);
if($result->num_rows>0)
{
    $row=$result->fetch_assoc();
?>
<form method="post">
<table>
<tr><td>enter cid</td><td><input readonly type="number" name="cid" value="<?php echo($row["cid"]);?>"</td></tr>
<tr><td>enter cname</td><td><input type="text" name="cname" value="<?php echo($row["cname"]);?>"</td></tr>
<tr><td><input type="submit" value="update category" name="update"></td></tr>
</table>
</form>
<?php
}

?>

