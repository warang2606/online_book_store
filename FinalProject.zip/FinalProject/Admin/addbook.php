<?php
require_once("../header.php");
?>

<?php
/* 
require_once("../database.php");
if(isset($_REQUEST["action"]))
{
    $file_name = $_FILES['fileUpload']['name'];
    $file_size =$_FILES['fileUpload']['size'];
    $file_tmp =$_FILES['fileUpload']['tmp_name'];
    $file_type=$_FILES['fileUpload']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['fileUpload']['name'])));
    
    $extensions= array("jpeg","jpg","png");
    
    if(in_array($file_ext,$extensions)=== false)
    {
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }    
   
    //To upload the file
    move_uploaded_file($_FILES["fileUpload"]["tmp_name"],
              "../Images/".$file_name);

    $bname = $_REQUEST["bname"];
    $price = $_REQUEST["price"];
    $description = $_REQUEST["desc"];
    $author= $_REQUEST["author"];
    $imageurl = $file_name;
    $cid = $_REQUEST["cid"];
    $sql = "insert into book (bname,price,description,author,cid,imageurl)"." values ('$bname',$price,'$description','$author',$cid,'$imageurl')";
    echo($sql);
    $con->query($sql);
    $con->close();
    header("Location:book.php");
}
$sql = "select * from Category";
$result = $con->query($sql);
*/
?>

<form method="post" enctype="multipart/form-data">
    <table class="table">
       <tr><td>Book Name</td>
        <td><input type="text" name="bname"/></td></tr>
        <tr><td>Price</td>
        <td><input type="number" name="price"/></td></tr>
        <tr><td>Description</td>
        <td><input type="text" name="desc"/></td></tr>
        <tr><td>Author</td>
        <td><input type="text" name="author"/></td></tr>
        <tr><td>Select Image</td>
        <td><input type="file" name="fileUpload"/></td></tr>
        
        <tr><td>Select Category</td>
        <td>
            <select>
                <option value="Select Restaurant:" value="default">(select category)</option>
                <option>Cookery</option>
                <option>Detective and Mystery</option>
                <option>Horror</option>
                <option>Classics</option>
                <option>Historical Fiction</option>
            </select>
            
        <?php
        /*
        if($result->num_rows>0)
        {
            while($row = $result->fetch_assoc())
            {
                echo("<option value=".$row["cid"].">".$row["cname"]."</option>");
            }

        }
*/
        ?>


         </select></td></tr>
    <tr><td><button class="btn-success" name="action" type="submit">Add Category</button></td><td></td></tr>
    </table>
</form>

<?php
/*
$con->close();
*/
?>

<?php
require_once("../footer.html");
?>