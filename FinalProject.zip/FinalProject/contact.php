<?php
  require_once("header.php");
?>  
<?php
require_once("database.php");
if(isset($_REQUEST["submit"]))
{
	$name=$_POST["name"];
	$email=$_POST["email"];
	$number=$_POST["number"];
	$message=$_POST["message"];

	$sql="insert into contact(name,email,number,message)"."values('$name','$email',$number,'$message')";
	$con->query($sql);
	$con->close();
  header("Location:messagesuccess.php");
  
}
 



?>



<!DOCTYPE html>
<html>
<head>
	<title>Online Book store</title>
	<style type="text/css">
		.button
		{
			background-color: #FFA500;
			border: none;
			color: white;
			padding: 20px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
			border-radius: 23px;
		}
		.label{
			color: white;
		}
	</style>

</head>
<body>
	<div class="container" style="background-image: url('pic2.jpg'); background-size: cover;width:40%; padding-top:7%; padding-bottom:7%;">
			<form method="post" class="form text-center" style="width:70%; margin-left:auto; margin-right:auto;">
			<div class="form-group">
			<label for="email" style="color: white; text-shadow: 2px 2px 3px #000000; font-size: 20px;">Email:</label>
			<input type="email" class="form-control" id="email" placeholder="Enter email">
			</div>
			<div class="form-group">
			<label for="pwd" style="color: white; text-shadow: 2px 2px 3px #000000; font-size: 20px;">Password:</label>
			<input type="password" class="form-control" id="pwd" placeholder="Enter password">
			</div>
			<div class="checkbox">
			<label><input type="checkbox"> Remember me</label>
			</div>
			<button type="submit" class="btn btn-danger">Submit</button>
			</form>

	</div>
<br>
<br>

<?php
$con->close();
?>

<?php
require_once("footer.html");
?>


</body>
</html>