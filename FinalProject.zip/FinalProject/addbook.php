<?php
require_once("header.php");
error_reporting(E_ALL);
?>

<?php
require_once("database.php");
if(isset($_REQUEST["action"]))
{
    $isValid = true;
    $errMsg = "";
    $file_name = $_FILES['fileUpload']['name'];
    $file_size =$_FILES['fileUpload']['size'];
    $file_tmp =$_FILES['fileUpload']['tmp_name'];
    $file_type=$_FILES['fileUpload']['type'];
    $file_ext=explode('.',$_FILES['fileUpload']['name']);
    $result = strtolower(end($file_ext));
    $extensions= array("jpeg","jpg","png");
    
    if(in_array($file_ext,$extensions)=== false)
    {
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }    
   
    //To upload the file
    move_uploaded_file($_FILES["fileUpload"]["tmp_name"],
              "Images".$file_name);

    
    if(isset($_REQUEST['bname']) && $_REQUEST['bname']!="")
    {
     $bname = $_REQUEST["bname"];
    }
    else
    {
        $isValid = false;
        $errMsg = $errMsg."<li>name is missing</li>";
    }


    if(isset($_REQUEST['price']) && $_REQUEST['price']!="")
    {
     $price = $_REQUEST["price"];
    }
    else
    {
        $isValid = false;
        $errMsg = $errMsg."<li>price is missing</li>";
    }

    if(isset($_REQUEST['desc']) && $_REQUEST['desc']!="")
    {
     $description = $_REQUEST["desc"];
    }
    else
    {
        $isValid = false;
        $errMsg = $errMsg."<li>Description is missing</li>";
    }


    if(isset($_REQUEST['author']) && $_REQUEST['author']!="")
    {
    $author= $_REQUEST["author"];
    }
    else
    {
        $isValid = false;
        $errMsg = $errMsg."<li>Author name is missing</li>";
    }

    $imageurl = $file_name;


    
    
    
    /*print_r($_REQUEST);*/
    if(isset($_REQUEST['cid']) && $_REQUEST['cid']!="")
    {
     $cid=$_REQUEST['cid'];
    }
    else
    {
        $isValid = false;
        $errMsg = $errMsg."<li>Category is missing</li>";
    }

    /*echo("insert into book (bname,price,description,author,imageurl,cid)values('$bname',$price,'$description','$author','$imageurl',$cid)");*/
    if($isValid)
    {
       $sql = "insert into book (bname,price,description,author,imageurl,cid)values('$bname',$price,'$description','$author','$imageurl',$cid)";
        /*echo($sql);*/
        /*die($sql);*/

        $con->query($sql);
        echo"<script>window.location.href='book.php';</script>";
    }
    else
    {
        echo '<h5 style="color:red;">Invalid Data, Please check fill input!</h5>
            <ul style="color:red;">'.$errMsg.'</ul>
        ';
    }
}

$sql = "select * from Category";
$result = $con->query($sql);

?>

<form method="post" enctype="multipart/form-data">
    <table class="table">
       <tr><td>Book Name</td>
        <td><input type="text" name="bname"/></td></tr>
        <tr><td>Price</td>
        <td><input type="number" name="price"/></td></tr>
        <tr><td>Description</td>
        <td><input type="text" name="desc"/></td></tr>
        <tr><td>Author</td>
        <td><input type="text" name="author"/></td></tr>
        <tr><td>Select Image</td>
        <td><input type="file" name="fileUpload"/></td></tr>
        
        <tr><td>Select Category</td>
        <td>
            <select name="cid" id="cid">
                <option value="">(select category)</option>
                
            
        <?php
        
        if($result->num_rows>0)
        {
            while($row = $result->fetch_assoc())
            {
                echo("<option value=".$row["cid"].">".$row["cname"]."</option>");
            }

        }

        ?>


         </select></td></tr>
    <tr><td><button class="btn-success" name="action" type="submit">Add Book</button></td><td></td></tr>
    </table>
</form>

<?php
$con->close();
?>

<?php
require_once("footer.html");
?>