<?php
session_start();
$con = mysqli_connect("localhost","root","","bookstore");
if(mysqli_connect_error())
{
	echo "<script> 
    alert('cannot connect to database');
    window.location.href='addtocart2.php';
    </script>";
    exit();  //if block true then exit() will not execute next php code
}
if($_SERVER["REQUEST_METHOD"]=="POST")
{
   if(isset($_POST['purchase']))	
   {
     $query1 = "INSERT INTO `order_manager`(`full_name`, `phone_no`, `address`, `pay_mode`) VALUES ('$_POST[full_name]','$_POST[mobile_no]','$_POST[address]','$_POST[pay_mode]')";
     if(mysqli_query($con,$query1))  //first connect pass then query pass
     {
       $order_id = mysqli_insert_id($con);  //fetch autoincremented id from db
       $query2 = "INSERT INTO `users_orders`(`order_id`, `bname`, `price`, `Quantity`) VALUES (?,?,?,?)";   
       $stmt = mysqli_prepare($con,$query2);
       if($stmt)
       {
        mysqli_stmt_bind_param($stmt,"isii",$order_id,$bname,$price,$Quantity);
        foreach($_SESSION['cart'] as $key => $values)  
        {
        	$bname = $values['bname'];
        	$price = $values['price'];
        	$Quantity = $values['Quantity'];
        	mysqli_stmt_execute($stmt);

        }
        unset($_SESSION['cart']); 
        echo "<script> 
    alert('order placed');
    window.location.href='home.php';
    </script>";
       }
       else
       {
         echo "<script> 
    alert('sql prepared statment error');
    window.location.href='addtocart2.php';
    </script>";
       }

     }
     else
     {
     	echo "<script> 
    alert('sql error');
    window.location.href='addtocart2.php';
    </script>";

     }

   }
}
?>