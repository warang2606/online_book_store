<?php
require_once("header.php");
?>

<div class="container">
<?php
include("database.php");
//Get cid from querystring
    $cid = $_REQUEST["cid"];
    $sql = "select b.bid,b.bname,b.price,b.author,b.imageurl,"."c.cname from book b inner join category c on "."b.cid = c.cid where c.cid = ".$cid;
    $result = $con->query($sql);
    if($result->num_rows>0)
    {
        echo("<table class='table table-bordered'>");
        echo("<tr><th>bid</th><th>bName</th><th>Price</th>"."<th>Category</th><th>author</th></th><th>Image</th><th>Details</th></tr>");
        while($row = $result->fetch_assoc())
        {
            echo("<tr>");
            echo("<td>".$row["bid"]."</td><td>".$row["bname"]."</td><td>".$row["price"]."</td>"."<td>".$row["cname"]."</td><td>".$row["author"]."</td><td><img src='Images".
            $row["imageurl"]."' height='50' width='60'/></td>".
          "<td><a href='viewdetails.php?bid=".$row["bid"]."'>View Details</a></td>");

            echo("</tr>");
        }
        echo("</table>");
    }

?>
</div>
<br>
<br>
<?php
require_once("footer.html");

?>