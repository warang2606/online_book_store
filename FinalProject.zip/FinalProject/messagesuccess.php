<?php
  require_once("header.php");
?> 




<!DOCTYPE HTML>

<html>
<head>
	<style type="text/css">
	    div.a
		{
			
			font-size: 250%;
			color: #FFA500;
		}
		
	</style>
</head>
<body>
<div class="a">
	your message recorded successfully
</div>
</body>
</html>




<?php
require_once("footer.html");
?>