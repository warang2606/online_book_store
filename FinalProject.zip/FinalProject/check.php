<?php
require_once("header.php");
?>

<?php
echo "please enter correct details";
?>
