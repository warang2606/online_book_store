<?php
require_once("header.php");
?>
<div class="container-fluid" style="background-color: rgb(204, 230, 255);">
  <div id="myCarousel" class="carousel slide" data-ride="carousel" style="width:70%; margin-left:auto; margin-right:auto;">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">

      <div class="item active">
        <img src="sliderimg1.jpg" >
        <div class="carousel-caption">
          <h2><b>One best book is equal to hundred good friends but one good friend is equal to a library</b></h2>
                  </div>
      </div>

      <div class="item">
        <img src="sliderimg2.jpg">
        <div class="carousel-caption">
          <h2><b>Books Build the better readers</b></h2>
                  </div>
      </div>
    
      <div class="item">
        <img src="sliderimg3.jpg">
        <div class="carousel-caption">
          <h2><b>Books are the mirrors of the soul</b></h2>
          
        </div>
      </div>

      <div class="item">
        <img src="sliderimg4.jpg">
        <div class="carousel-caption">
          <h2><b>Book is a gift you can open again and again</b></h2>
          
        </div>
      </div>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<?php
require_once("footer.html");
?>