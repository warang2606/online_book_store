<?php
require_once("header.php");
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
?>
<html>
<head>
    <style type="text/css">
        .button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button4 {border-radius: 12px;}
.button5 {border-radius: 12px; float: right;}
    </style>
<body>
<h3>Books</h3>
<a href="addbook.php">
    <button class="button button4">Add Book</button>
</a> 

<a href="adminmodules.php">
    <button  class="button button5">Back To Admin Panel</button>
</a>
</body>
</head>
</html>

<?php

include("database.php");
    $sql = "select b.bid,b.bname,b.price,b.description,b.author,b.imageurl, "." c.cname from book b inner join category c on b.cid = c.cid order by bid asc";
    $result = $con->query($sql);
    if($result->num_rows>0)
    {
        echo("<table class='table'>");
        echo("<tr><th>Bid</th><th>BName</th><th>Price</th>"."<th>Description</th><th>Author</th><th>Category Name</th><th>Image</th><th>Edit</th><th>Delete</th></tr>");
        while($row = $result->fetch_assoc())
        {
            echo("<tr>");
            echo("<td>".$row["bid"]."</td><td>".$row["bname"]."</td><td>".$row["price"]."</td><td>".$row["description"]."</td><td>".$row["author"]."</td><td>".$row["cname"]."</td><td><img src='Images". $row["imageurl"]."' height='80' width='60'/></td>");
            echo("<td><a href=editbook.php?bid=".$row["bid"]."><button>Edit</button></a></td>");
            echo("<td><a href=deletebook.php?bid=".$row["bid"]."><button>Delete</button></a></td>");
            echo("</tr>");
        }
        echo("</table>");
    }

require_once("footer.html");
?>



