<?php

require_once("header.php");
?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
		
		.button5 {border-radius: 12px; float: right;}
	</style>
</head>

</html>

<?php

if(isset($_REQUEST["action"]))
{

    include("database.php");

    $sql = "insert into Category (cname) values ('".$_REQUEST["cname"]."')";
        
        $con->query($sql);
        header("Location:category.php");
}
    

?>
<a href="adminmodules.php">
    <button  class="button button5">Back To Admin Panel</button>
</a>
<form method="post">
    <table class="table">
       <tr><td>Category Name</td>
        <td><input type="text" name="cname"/></td></tr>
    <tr><td><button class="btn-success" name="action" type="submit">Add Category</button></td><td></td></tr>
    </table>
</form>

<?php
require_once("footer.html");
?>