<?php
require_once("header.php");
?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		 .button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button1 {border-radius: 12px;}
.button2 {border-radius: 12px;}
.button3 {border-radius: 12px;}
.button4 {border-radius: 12px;}
.button5 {border-radius: 12px;}
	</style>
</head>


<body>

<div class="container">
	<table class="table">
	<tr><td><a href="book.php">
    <button class="button button1">All Books Details</button></a> </td></tr>

	<tr><td><a href="category.php">
	 <button class="button button2">All Category Details</button></a></td></tr>

    <tr><td><a href="messageinfo.php">
   <button class="button button3">User Message</button></a></td></tr>

    <tr><td><a href="userdetails.php">
    	<button class="button button4">User Registration Details</button></a></td></tr>

     <tr><td><a href="userorders2.php">
      <button class="button button5">User Orders</button></a></td></tr>



	</table>
	</body>

</div>
</html>