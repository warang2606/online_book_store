<?php
require_once("header.php");

?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.abc
		{
			font: italic small-caps bold 45px/30px Georgia, serif;
			align-content: center;
			color: #FF0000;
		}
		
	</style>
</head>

</html>

<div class="container" style="background-image: url('pic4.jpg'); background-size: cover;width:50%; padding-top:7%; padding-bottom:7%;">
  <h2 class="text-center" style="margin-bottom:50px; font-weight:bold;">Admin Login</h2>
  <form method="post" action="AdminValidate.php" class="form text-center" style="width:80%; margin-left:auto; margin-right:auto;">
  <h4 style="color:black;">Username:</h4><input type="text" class="form-control" placeholder="username" name="uname" style="margin:20px 0px;">
  <h4 style="color:black;">Password:</h4><input type="password" class="form-control" placeholder="password" name="pwd" style="margin:20px 0px;">
  <button type="submit" class="btn-success" name="login1">Submit
  </table>
  </form>
</div>
<br>
<br>
<?php

require_once("footer.html");

?>