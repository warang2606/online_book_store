<?php
session_start();
require_once("database.php");
if(isset($_REQUEST["login1"]))
{
$uname=$_REQUEST["uname"];
$pwd=$_REQUEST["pwd"];
$sql="select count(*) as 'count' from AdminLogin where username='$uname' and password='$pwd'";
$result=$con->query($sql);
if($result->num_rows>0)
{
    $row=$result->fetch_assoc();
    if($row["count"]==1)
    {
        $_SESSION["uname"]=$uname;
        header("location:adminmodules.php");
    }
    else
    {
        echo "please enter correct details";
    }


}
}

?>
