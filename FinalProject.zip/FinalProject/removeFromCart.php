
<?php
session_start();
    if(!isset($_SESSION["cart"]))
    {
        echo("<h1>No items in cart!!</h1>");
    }
    else
    {
        $cart = $_SESSION["cart"];
        $bid = $_REQUEST["bid"];
        unset($cart[$bid]); //delete element from array
        $_SESSION["cart"] = $cart; //Update the session variable
        header("Location:ShowAllCartItems.php");
    }

?>

