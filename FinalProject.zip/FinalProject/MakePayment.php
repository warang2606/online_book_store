<?php
require_once("header.php");
?>
<?php

if(isset($_REQUEST['amt_submit']))
{
   $amt=$_REQUEST['amt'];
}

?>

<div class="container">
	<h1>Payment Process</h1>
<form method="post" action="Paymentprocess.php">
 <table class='table'>
   

	<tr>
   		<td>Name</td>
   		<td><input type="name" name="name" placeholder="Enter Your Name"></td>
   </tr>

	<tr>
   		<td>Account Number</td>
   		<td><input type="number" name="anumber" placeholder="Enter Account Number"></td>
   </tr>
   <tr>
         <td>Expiry Month</td>
         <td><input type="text" name="emonth" placeholder="Enter Expiry Month"></td>
   </tr>
   <tr>
         <td>Expiry Year</td>
         <td><input type="number" name="eyear" placeholder="Enter Expiry Year"></td>
   </tr>
   <tr>
         <td>CVV Number</td>
         <td><input type="number" name="cnumber" placeholder="Enter CVV Number"></td>
   </tr>
   <tr>
         <td>Amount</td>
         <td><input type="text" name="amt" value="<?Php echo $amt; ?>" readonly></td>
   </tr>
   


   <tr>
   		<tr><td><button type="submit" class="btn-info" name="proceed">proceed</td></tr>
   </tr>
   	
   </form>
</table>
</div>

<?php
require_once("footer.html");
?>



	