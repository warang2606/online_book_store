<?php
session_start();
if(isset($_REQUEST["proceed"]))
{
   include("database.php");
   $user=$_SESSION['uname']; //to get uname from session
   //$check="select * from userinfo where username='$user'";
   //$result=$con->query($check);
   //$row=$result->fetch_assoc();
   //$uname=$row['username'];
   include("database.php");

   $name = $_REQUEST["name"]; //to fetch data from makepayment form
   $anumber = $_REQUEST["anumber"];
   $emonth = $_REQUEST["emonth"];
   $eyear = $_REQUEST["eyear"];
   $cnumber = $_REQUEST["cnumber"];
   $amt = $_REQUEST["amt"];
   $sql="INSERT INTO seller_account(name,anumber,emonth,eyear,cnumber,amt)VALUES('$name',$anumber,$emonth,$eyear,$cnumber,$amt)";
   $con->query($sql);
   $con->close();
   echo "payment successfull";
}
?>

