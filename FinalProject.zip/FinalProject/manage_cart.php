<?php
session_start();

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	if(isset($_POST['Add_To_Cart']))
	{
		if(isset($_SESSION['cart']))  //is cart named index is set under $_SESSION
		{
		  $myitems=array_column($_SESSION['cart'],'bname'); //in array_column we store existing cart items
		  if(in_array($_POST['bname'],$myitems))   //in_array search specific value in array($myitems)
		  {
             echo"<script>
             alert('item alredy added');
             window.location.href='home.php';

             </script>";
		  }
		  else   //this part execute if item not added
		  {
		  $count=count($_SESSION['cart']);
          $_SESSION['cart'][$count]=array('bname'=> $_POST['bname'],'price'=>$_POST['price'],'Quantity'=>1);
            echo"<script>
			alert('item added');
			window.location.href='addtocart2.php';
			</script>";
          
		}
	}
else
{
 $_SESSION['cart'][0]=array('bname'=> $_POST['bname'],'price'=>$_POST['price'],'Total'=>$_POST['Total'],'Quantity'=>1);
echo"<script>
alert('item added');
window.location.href='addtocart2.php';
</script>";
                            
}
	}
	if(isset($_POST['remove_item']))
	{
		foreach($_SESSION['cart'] as $key => $value)
		{
			if($value['bname'] == $_POST['bname'])  //if session contain bname is match to the remove button bname
			{
			unset($_SESSION['cart'][$key]);   //to remove the index
			$_SESSION['cart']=array_values($_SESSION['cart']);   //rearrange the array index after deleting item
			echo"<script>
			alert('Item removed');
			window.location.href='addtocart2.php';
			</script>";
		    }
		}
	}
	if(isset($_POST['mod_quantity']))    
	{
		foreach($_SESSION['cart'] as $key => $value)  //cart item pass with its value and bname etc
		{
			if($value['bname'] == $_POST['bname'])  //if session contain bname = bname send through post method
			{
			  $_SESSION['cart'][$key]['Quantity']=$_POST['mod_quantity'];  //quantity index is change by quantity change by post

					  echo"<script>
					window.location.href='addtocart2.php';
					</script>";
		    }
		}
	}
}
?>