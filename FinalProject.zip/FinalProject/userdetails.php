<?php
require_once("header.php")
?>
<html>
<head>
    <style type="text/css">
        .button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button4 {border-radius: 12px; float: right;}
    </style>
<a href="adminmodules.php">
	<button  class="button button4">Back to admin panel</button>

</a>

<h3>User Registration Details</h3>

<?php
include("database.php");

$sql="select * from userinfo";
$result=$con->query($sql);
if($result->num_rows>0)
{
	echo("<table class='table'>");
	echo("<tr><th>uid</th><th>FirstName</th><th>LastName</th><th>Address</th><th>Mobile</th><th>Email</th><th>Username</th><th>password</th>");
	while($row = $result->fetch_assoc())
	{
		echo("<tr>");
		echo("<td>".$row["uid"]."</td><td>".$row["firstname"]."</td><td>".$row["lastname"]."</td><td>".$row["address"]."</td><td>".$row["mobile"]."</td><td>".$row["email"]."</td><td>".$row["username"]."</td><td>".$row["password"]."</td>");
	}
	echo("</table>");
}
require_once("footer.html");

?>