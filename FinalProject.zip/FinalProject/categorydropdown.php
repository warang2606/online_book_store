<?php
include("database.php");

$sql = "select * from category";
$result = $con->query($sql);
if($result->num_rows>0)
{
    while($row = $result->fetch_assoc())        
    {            
        echo("<li>");
        echo("<a href='showproducts.php?cid=".$row["cid"]."'>".$row["cname"]."</a>");
        echo("</li>");
    }        
}
?>