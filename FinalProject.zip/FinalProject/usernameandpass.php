<!DOCTYPE html>
<html>
<head>
	<title>store in database</title>
</head>
<body>
  <form method="post">
  	<table border="1">
  		<tr>
  			<td>username</td>
  			<td><input type="text" name="uname"></td>
  		</tr>
  		<tr>
  			<td>password</td>
  			<td><input type="password" name="pwd"></td>
  		</tr>

  	</table>

  </form>
</body>
</html>