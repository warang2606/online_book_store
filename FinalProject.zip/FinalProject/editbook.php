<?php
require_once("header.php");
?>

<?php
if(isset($_REQUEST["Update"]))
{
    require_once("database.php");
    
    $bid=$_REQUEST["bid"];
    $bname=$_REQUEST["bname"];
    $price=$_REQUEST["price"];
    $desc=$_REQUEST["desc"];
    $author=$_REQUEST["author"];
    $sql="update book set bname='$bname',price=$price,description='$desc',author='$author' where bid=$bid";
    $con->query($sql);
    $con->close();
    header("location:book.php");
}
?>
<?php
require_once("database.php");
$bid=$_REQUEST["bid"];
$sql="select * from book where bid=$bid";
$result=$con->query($sql);
if($result->num_rows>0)
{
    $row=$result->fetch_assoc();
?>
<form method="post">
<table>
<tr><td>enter bid</td><td><input readonly type="number" name="bid" value="<?php echo($row["bid"]);?>"</td></tr>
<tr><td>enter bname</td><td><input type="text" name="bname" value="<?php echo($row["bname"]);?>"</td></tr>
<tr><td>enter price</td><td><input type="number" name="price" value="<?php echo($row["price"]);?>"</td></tr>
<tr><td>enter description</td><td><input type="text" name="desc" value="<?php echo($row["description"]);?>"</td></tr>
<tr><td>enter Author Name</td><td><input type="text" name="author" value="<?php echo($row["author"]);?>"</td></tr>
<tr><td><input type="submit" value="update product" name="Update"></td></tr>
</table>
</form>
<?php
}
require_once("footer.html");
?>
