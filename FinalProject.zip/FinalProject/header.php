<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Online Book store</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
    .carousel-inner > .item > img,
  .carousel-inner > .item > a > img 
  {
   width: 100%;
  height: 20%;
   
  }
  
     
  
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    .navbar 
    {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
    
      
    
    /* Remove the jumbotron's default bottom margin */ 
     .jumbotron
      {
      margin-bottom: 0;
      background-image: url(headerpic2.jpg);
      background-size: cover;
    }
      .jumbotron h1
      {
        color:red;
        font-family: garamond;
        font-weight: bold;
      }
      .jumbotron marquee
      {
        color:rgb(0,0,139);
        font-family: georgia;
        font-style: italic;
      }
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
</head>
<body>
  <div class="container"></div>
<div class="jumbotron">
  <div class="container text-center" style="background-color: rgb(255, 255, 255, 0.5); border-radius: 20px;">
    <h1>Online Book Store</h1>
    <marquee  direction="left" ><h2>
                Make your life successful with reading books!!  Get your favorite book here.!! We respect readers, just like you.!! Books that inspire you!!</h2>
    </marquee>
  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#"><img src="logo2.jpg" height="60px" width="70px"></img></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="home.php">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Category
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <?php 
            include("categorydropdown.php");
            ?>
           </ul>
        </li>
        <li><a href="contact.php">Contact Us</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
      <ul class="nav navbar-nav navbar-right">
        <?php
         if(!isset($_SESSION["uname"]))
         {
           ?>
           <li><a href="login.php"><span class="glyphicon glyphicon-user"></span>Login</a></li>
          
         <?php
         }
         else
         {
           ?>
<li><a href="logout.php"><span class="glyphicon glyphicon-user"></span>Logout</a></li>
          
         <?php
         }
        ?>
        <?php
        $count=0;
        if(isset($_SESSION['cart']))
        {
          $count=count($_SESSION['cart']);
        }
        ?>
        <li><a href="addtocart2.php"><span class="glyphicon glyphicon-shopping-cart"></span> My Cart (<?php echo $count; ?>)</a></li>
        <li><a href="AdminLogin.php"><span class="glyphicon glyphicon-user"></span>Admin Login</a></li>

      </ul>
    </div>
  </div>  
</nav>
