 <?php
require_once("header.php");
?>

<div class="container" style="background-image: url('pic5.jpg'); background-size: cover;width:50%; padding-top:7%; padding-bottom:7%;">
  <h2 class="text-center" style="margin-bottom:50px; font-weight:bold;">User Login</h2>
  <form method="post" action="validate.php" class="form text-center" style="width:80%; margin-left:auto; margin-right:auto;">
  <h4 style="color:black;">Username:</h4><input type="text" class="form-control" placeholder="username" name="uname" style="margin:20px 0px;">
  <h4 style="color:black;">Password:</h4><input type="password" class="form-control" placeholder="password" name="pwd" style="margin:20px 0px;">
  <input type="submit" class="btn-success" class="form-control" name="login" value="Submit" style="margin:20px 0px;">
  <br>
  <a href="register.php" style="margin:20px 0px; font-size:20px; color:black;">Are you visiting first time?Click Here</a>
  </table>
  </form>
</div>
<br>
<br>

<?php
require_once("footer.html");
?>