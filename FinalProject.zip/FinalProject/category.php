<?php
require_once("header.php");
?>
<!DOCTYPE html>
<html>
<head>
   <style type="text/css">
     .button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button1 {border-radius: 12px;}
.button2 {border-radius: 12px; float: right;}
       
   </style> 

<body>
<h3>Categories</h3>
<a href="addCategory.php">
  <button class="button button1">Add Category</button>
</a>
<a href="adminmodules.php">
  <button class="button button2">Back to admin panel</button>
</a>
</body>
</head>
</html>
<?php

include("database.php");


    $sql = "select * from category";
    $result = $con->query($sql);
  if($result->num_rows>0)
    {
        echo("<table class='table'>");
        echo("<tr><th>Cid</th><th>CName</th>"."<th>Edit</th><th>Delete</th></tr>");
        while($row = $result->fetch_assoc())
        {
            echo("<tr>");
            echo("<td>".$row["cid"]."</td><td>".$row["cname"]."</td>");
            echo("<td><a href=editCategory.php?cid=".$row["cid"]."><button>Edit</button></a></td>");
            echo("<td><a href=deleteCategory.php?cid=".$row["cid"]."><button>Delete</button></a></td>");
            echo("</tr>");

        }
        echo("</table>");
    }
require_once("footer.html");
?>