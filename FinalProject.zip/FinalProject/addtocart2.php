<?php
require_once("header.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>cart</title>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-lg-12 text-center border rounded bg-light">
			<h1>My cart</h1>
		</div>
		<div class="col-lg-12">
			
			<table class="table table-bordered">
  <thead class="text-center">
    <tr>
      <th scope="col">serial No</th>
      <th scope="col">book name</th>
      <th scope="col">price</th>
      <th scope="col">Quantity</th>
      <th scope="col">Total</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody class="text-center">
  	<?php
        if(isset($_SESSION['cart']))
        {
        foreach($_SESSION['cart'] as $key => $value)  //each item index = $key or index(bname,price) = $value
        {
        	$sr=$key+1;
        	echo"
            <tr>
            <td>$sr</td>
            <td>$value[bname]</td>
            <td>$value[price]<input type='hidden' class='iprice' value='$value[price]'></td>
            <td>
            <form action='manage_cart.php' method='POST'>
       <input class='text-center iquantity' name='mod_quantity' onchange='this.form.submit();' type='number' min='1' max='10' value='$value[Quantity]'>
       <input type='hidden' name='bname' value='$value[bname]'>
       </form>
       </td>
            <td class='itotal'></td>
            <td>
            <form action='manage_cart.php' method='POST'>
            <button name='remove_item' class='btn btn-sm btn-outline-danger'>REMOVE</button>
            <input type='hidden' name='bname' value='$value[bname]'>
            </form>
            </td>
            </tr>

          ";
        }
    }
  	?>
    
    	
      
  </tbody>
</table>
</div>

<div class="container">
<div style="margin-left:auto; margin-right:auto; width:50%; margin-bottom:7%;;">
  <div class="border bg-light rounded text-center"></div>
          <div class="text-center">
          <h4 style="display:inline-block;"> Grand Total:</h4>
        	<h4 id="gtotal" style="display:inline-block;" align="right"></h4>
          </div>
        	
          <br>
          <br>
          <br>
          <?php
          if(isset($_SESSION['cart']) && count($_SESSION['cart'])>0)  //if cart item greater than 0
          {
          ?>
        	<form action="purchase.php" method="post">
            <div class="form-group">
              <label>Full Name</label>
              <input type="text" name="full_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label>Mobile Number</label>
              <input type="number" name="mobile_no" class="form-control" required >
            </div>
            <div class="form-group">
              <label>Address</label>
              <input type="text" name="address" class="form-control" required>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="pay_mode" value="cod" id="flexRadioDefault2" checked>
              <label class="form-check-label" for="flexRadioDefault2">
                Cash on Delivery
              </label>
            </div>
        		<button class="btn btn-primary btn-block" name="purchase">Make purchase</button>
        	</form>
          <?php
          }
          ?>
        </div>

	</div>
</div>
</div>


<script>

	var gt = 0;
	var iprice = document.getElementsByClassName('iprice');
	var iquantity = document.getElementsByClassName('iquantity');
	var itotal = document.getElementsByClassName('itotal');
    var gtotal = document.getElementById('gtotal');
	function subTotal()
	{
		gt=0;
		for(i=0;i<iprice.length;i++)
		{

          itotal[i].innerText=(iprice[i].value)*(iquantity[i].value);

          gt=gt+(iprice[i].value)*(iquantity[i].value);
		}
		gtotal.innerText = gt;
	}
	subTotal();	
</script>
<?php
require_once("footer.html");
?>

</body>
</html>